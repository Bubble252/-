% 生成示例雷达图像
radar_image = zeros(500, 500, 3, 'uint8');  % 创建一个空白图像
[rows, cols, ~] = size(radar_image);

% 画出雷达扫描效果
theta = linspace(0, 2*pi, 100);
for r = 1:5:250
    x = r * cos(theta) + cols/2;
    y = r * sin(theta) + rows/2;
    radar_image = insertShape(radar_image, 'Line', [x; y]', 'Color', 'white', 'LineWidth', 2);
end

% 画出雷达中心和辐射线
for t = 0:pi/8:2*pi
    x = [0, 250 * cos(t)] + cols/2;
    y = [0, 250 * sin(t)] + rows/2;
    radar_image = insertShape(radar_image, 'Line', [x; y], 'Color', 'white', 'LineWidth', 2);
end

% 保存并显示雷达图像
imwrite(radar_image, 'example_radar_image.jpg');
imshow(radar_image);
