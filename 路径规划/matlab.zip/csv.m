% 生成模拟点云数据
num_points = 1000;
Points_X = rand(num_points, 1) * 100;  % 生成0到100之间的随机数
Points_Y = rand(num_points, 1) * 100;
Points_Z = rand(num_points, 1) * 50;   % 生成0到50之间的随机数

% 障碍物和目标物位置
obstacle_positions = [
    20, 30;
    50, 70;
    80, 40
];
target_position = [10, 10];

% 创建表格
data_table = table(Points_X, Points_Y, Points_Z);

% 将数据写入CSV文件
writetable(data_table, 'simulated_point_cloud_data.csv');
