% 读取生成的CSV文件
data = readtable('simulated_point_cloud_data.csv');

% 提取点云数据中的x, y, z坐标
x = data.Points_X;
y = data.Points_Y;
z = data.Points_Z;

% 假设在点云中间某个位置处高度最高
mid_index = round(length(x) / 2);  % 假设在点云数据中间位置
mid_point = [x(mid_index), y(mid_index), z(mid_index)];  % 中间点的坐标

% 确定起点和终点的坐标
[~, start_index] = min(y);  % 找到y最小值的索引作为起点
[~, end_index] = max(y);    % 找到y最大值的索引作为终点
start_point = [x(start_index), y(start_index), z(start_index)];
end_point = [x(end_index), y(end_index), z(end_index)];

% 创建网格
[X, Y] = meshgrid(linspace(min(x), max(x), 100), linspace(min(y), max(y), 100));
Z = griddata(x, y, z, X, Y, 'natural');

% 将 start_point 和 target_position 转换为网格坐标
start_point_grid = [find(X(1,:) >= start_point(1), 1), find(Y(:,1) >= start_point(2), 1)];
target_position_grid = [find(X(1,:) >= target_position(1), 1), find(Y(:,1) >= target_position(2), 1)];

% 添加障碍物和目标物的势函数值
obstacle_positions = [
    20, 30;
    50, 70;
    60, 40
];
target_position = [10, 10];

% 将障碍物位置的势函数设为较大值（正方形）
for i = 1:size(obstacle_positions, 1)
    x_range = obstacle_positions(i, 1) + [-5 5];
    y_range = obstacle_positions(i, 2) + [-5 5];
    Z(X >= x_range(1) & X <= x_range(2) & Y >= y_range(1) & Y <= y_range(2)) = 100;
end

% 将目标物位置的势函数设为较小值（圆形）
radius = 5;
[rows, cols] = size(Z);
for i = 1:rows
    for j = 1:cols
        distance = sqrt((X(i, j) - target_position(1))^2 + (Y(i, j) - target_position(2))^2);
        if distance <= radius
            Z(i, j) = -100;
        end
    end
end

% 计算梯度
[FX, FY] = gradient(Z);

% 调用路径规划函数
path = astar(start_point_grid, target_position_grid, obstacle_positions, X, Y, Z);

% 绘制梯度场
figure;
contourf(X, Y, Z, 20);
hold on;
quiver(X, Y, FX, FY, 'k');

% 绘制起点和终点
plot3(start_point(1), start_point(2), start_point(3), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
plot3(end_point(1), end_point(2), end_point(3), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');

% 绘制正方形障碍物
for i = 1:size(obstacle_positions, 1)
    rectangle('Position', [obstacle_positions(i, 1) - 5, obstacle_positions(i, 2) - 5, 10, 10], 'EdgeColor', 'y', 'LineWidth', 2);
end

% 绘制圆形目标物
viscircles(target_position, radius, 'EdgeColor', 'b');

% 绘制路径
plot(X(path(:,2)), Y(path(:,1)), 'b-', 'LineWidth', 2);
hold off;

% 导入雷达图像
radar_image = imread('example_radar_image.jpg');  % 替换为你的雷达图像路径

% 显示雷达图像
figure;
imshow(radar_image);
hold on;

% 将MATLAB生成的图像叠加在雷达图像上
h = imshow(zeros(size(radar_image)));
set(h, 'AlphaData', 0.5);  % 使MATLAB图像半透明显示
f = getframe(gca);
alpha_data = f.cdata(:, :, 1) == 0 & f.cdata(:, :, 2) == 0 & f.cdata(:, :, 3) == 0;
radar_image(repmat(~alpha_data, [1 1 3])) = f.cdata(repmat(~alpha_data, [1 1 3]));
imshow(radar_image);
hold off;

% 绘制路径在雷达图像上
figure;
imshow(radar_image);
hold on;
plot(X(path(:,2)), Y(path(:,1)), 'r-', 'LineWidth', 2);
hold off;

% A*路径规划函数
function path = astar(start_point, target_position, obstacle_positions, X, Y, Z)
    % 将目标物位置的势函数设为较小值
    radius = 5;
    [rows, cols] = size(Z);
    for i = 1:rows
        for j = 1:cols
            distance = sqrt((X(i, j) - target_position(1))^2 + (Y(i, j) - target_position(2))^2);
            if distance <= radius
                Z(i, j) = -100;
            end
        end
    end

    % 定义启发式函数（欧几里得距离）
    heuristic = @(a, b) sqrt(sum((a - b).^2));

    % 初始化开闭集
    open_set = start_point;
    closed_set = [];
    g_score = inf(size(X));
    g_score(start_point(1), start_point(2)) = 0;
    f_score = inf(size(X));
    f_score(start_point(1), start_point(2)) = heuristic(start_point, target_position);
    came_from = NaN(size(X, 1), size(X, 2), 2);

    % A*算法主循环
    while ~isempty(open_set)
        % 从开集中选择具有最低f_score的节点
        [~, idx] = min(f_score(sub2ind(size(X), open_set(:,1), open_set(:,2))));
        current = open_set(idx, :);

        % 如果到达目标点，则重建路径
        if norm(current - target_position) <= radius
            path = [];
            while ~isnan(came_from(current(1), current(2), 1))
                path = [current; path];
                current = squeeze(came_from(current(1), current(2), :))';
            end
            path = [start_point; path];
            return;
        end

        % 将当前节点从开集中移除，加入闭集
        open_set(idx, :) = [];
        closed_set = [closed_set; current];

        % 获取邻居节点
        neighbors = [current(1) + 1, current(2);
                     current(1) - 1, current(2);
                     current(1), current(2) + 1;
                     current(1), current(2) - 1];
        neighbors = neighbors(neighbors(:, 1) > 0 & neighbors(:, 1) <= size(X, 1) & ...
                              neighbors(:, 2) > 0 & neighbors(:, 2) <= size(X, 2), :);

        for k = 1:size(neighbors, 1)
            neighbor = neighbors(k, :);
            if ismember(neighbor, closed_set, 'rows')
                continue;
            end

            tentative_g_score = g_score(current(1), current(2)) + heuristic(current, neighbor);

            if ~ismember(neighbor, open_set, 'rows')
                open_set = [open_set; neighbor];
            elseif tentative_g_score >= g_score(neighbor(1), neighbor(2))
                continue;
            end

            came_from(neighbor(1), neighbor(2), :) = current;
            g_score(neighbor(1), neighbor(2)) = tentative_g_score;
            f_score(neighbor(1), neighbor(2)) = g_score(neighbor(1), neighbor(2)) + heuristic(neighbor, target_position);
        end
    end

    % 如果未找到路径，则返回空数组
    path = [];
end
